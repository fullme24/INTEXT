from django.apps import AppConfig


class ProfileInfoConfig(AppConfig):
    name = 'profile_info'
